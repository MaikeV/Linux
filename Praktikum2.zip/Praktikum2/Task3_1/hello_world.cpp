#include "hello_world.h"

void helloWorld::hello() {
  std::cout << "Hello World" << std::endl;
}
