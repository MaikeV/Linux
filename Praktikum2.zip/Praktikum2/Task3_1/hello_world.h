#include <iostream>

class helloWorld {
	public:
		static void hello();
};
