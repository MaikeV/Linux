#include "hello_world.h"

int main() {
  helloWorld::hello();
  return 0;
}
